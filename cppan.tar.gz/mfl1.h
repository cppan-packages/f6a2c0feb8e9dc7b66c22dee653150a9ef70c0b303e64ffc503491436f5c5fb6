#pragma once

#include <string>

CPPAN_PROLOG

CPPAN_EXPORT int f();

struct CPPAN_EXPORT Hello
{
  std::string g();
};

CPPAN_EPILOG
