#include "mfl1.h"

CPPAN_PROLOG

int f()
{
  return 42;
}

std::string Hello::g()
{
  return "Hello, CPPAN World!";
}

CPPAN_EPILOG
